using System;

class MainClass {
  public static void Main (string[] args) {
    Console.WriteLine ("Hello World")
    int a = 4, b = 3
    int c = a + b;
    Console.WriteLine(c)
    
  }
}